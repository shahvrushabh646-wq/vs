import { PALETTE_IDS, PALETTES } from "./look";
import type { Beat, Category, LayoutId, MotionId, Template, TransitionId } from "./types";

const cinema: Beat[] = [
  { role: "OPEN", label: "Atmosphere" },
  { role: "HERO", label: "Hero" },
  { role: "DETAIL", label: "Detail" },
  { role: "MOVE", label: "Movement" },
  { role: "END", label: "Meaning" },
];
const edit: Beat[] = [
  { role: "HOOK", label: "Hook" },
  { role: "HERO", label: "Feature" },
  { role: "DETAIL", label: "Detail" },
  { role: "NOTE", label: "Context" },
  { role: "END", label: "Close" },
];
const fest: Beat[] = [
  { role: "HOOK", label: "Hook" },
  { role: "CUT", label: "Cut" },
  { role: "PEAK", label: "Peak" },
  { role: "END", label: "Release" },
];
const story: Beat[] = [
  { role: "OPEN", label: "Opening" },
  { role: "HERO", label: "Hero" },
  { role: "DETAIL", label: "Detail" },
  { role: "MEAN", label: "Meaning" },
  { role: "END", label: "Close" },
];
const doc: Beat[] = [
  { role: "OPEN", label: "Establish" },
  { role: "HERO", label: "Record" },
  { role: "DETAIL", label: "Evidence" },
  { role: "NOTE", label: "Context" },
  { role: "END", label: "Close" },
];

const MOTIONS: MotionId[] = ["slow-push", "slow-pull", "pan-left", "pan-right", "pan-up", "reveal", "diagonal", "crop-punch", "drift"];
const TRANSITIONS: TransitionId[] = ["fade", "crossfade", "slide", "wipe", "film-cut", "flash", "reveal", "mask", "hard"];

type Master = {
  id: string;
  name: string;
  category: Category;
  description: string;
  layout: LayoutId;
  duration: number;
  beats: Beat[];
};

const MASTERS: Master[] = [
  { id: "cinematic-dawn", name: "Cinematic Dawn", category: "Cinematic", description: "Full-bleed frame, letterbox, and a slow push into the subject.", layout: "dawn", duration: 24, beats: cinema },
  { id: "cinematic-focus", name: "Cinematic Focus", category: "Cinematic", description: "Spotlight vignette with the subject held in a quiet circle.", layout: "focus", duration: 24, beats: cinema },
  { id: "cinematic-journey", name: "Cinematic Journey", category: "Cinematic", description: "Hero window plus a detail strip, cut as a short journey.", layout: "journey", duration: 26, beats: cinema },
  { id: "cinematic-meaning", name: "Cinematic Meaning", category: "Cinematic", description: "Large picture, almost no chrome, title held low and still.", layout: "meaning", duration: 22, beats: story },
  { id: "editorial-split", name: "Editorial Split", category: "Editorial", description: "Type column beside a tall picture.", layout: "split", duration: 20, beats: edit },
  { id: "editorial-column", name: "Editorial Column", category: "Editorial", description: "Narrow headline column beside a tall photograph.", layout: "column", duration: 20, beats: edit },
  { id: "editorial-frame", name: "Editorial Frame", category: "Editorial", description: "Framed photograph with a caption sitting under the print.", layout: "eframe", duration: 18, beats: edit },
  { id: "editorial-story", name: "Editorial Story", category: "Editorial", description: "Picture, then a stacked headline, deck, and close.", layout: "estory", duration: 20, beats: edit },
  { id: "magazine-cover", name: "Magazine Cover", category: "Magazine", description: "Masthead, cover image, and an issue-style headline.", layout: "cover", duration: 18, beats: edit },
  { id: "magazine-feature", name: "Magazine Feature", category: "Magazine", description: "Top photograph, article headline, and a short deck on paper.", layout: "feature", duration: 18, beats: edit },
  { id: "magazine-bold", name: "Magazine Bold", category: "Magazine", description: "Oversized type plate over a full-bleed photograph.", layout: "mbold", duration: 16, beats: edit },
  { id: "polaroid-stack", name: "Polaroid Stack", category: "Memory", description: "Tilted print with a white border and a caption in the foot.", layout: "polaroid", duration: 20, beats: story },
  { id: "memory-diary", name: "Memory Diary", category: "Memory", description: "Paper page, taped photograph, and a journal line.", layout: "diary", duration: 22, beats: story },
  { id: "travel-scrapbook", name: "Travel Scrapbook", category: "Memory", description: "Several prints placed like a travel page, in selection order.", layout: "scrapbook", duration: 18, beats: story },
  { id: "collage-grid", name: "Collage Grid", category: "Collage", description: "Separate cells for each selected asset. Never one photo tiled.", layout: "grid", duration: 14, beats: fest },
  { id: "dynamic-grid", name: "Dynamic Grid", category: "Collage", description: "One large plate and supporting crops beside it.", layout: "dgrid", duration: 16, beats: fest },
  { id: "photo-wall", name: "Photo Wall", category: "Collage", description: "Overlapping prints at different angles and crops.", layout: "wall", duration: 16, beats: fest },
  { id: "multi-frame", name: "Multi Frame", category: "Collage", description: "Main frame with smaller supporting frames underneath.", layout: "mframe", duration: 16, beats: edit },
  { id: "sacred-frame", name: "Sacred Frame", category: "Devotional", description: "Arched window, brass rule, and a quiet title.", layout: "sacred", duration: 26, beats: story },
  { id: "temple-light", name: "Temple Light", category: "Devotional", description: "Warm light from above and a restrained lower title.", layout: "temple", duration: 26, beats: cinema },
  { id: "devotional-story", name: "Devotional Story", category: "Devotional", description: "Centered portrait window with a line beneath.", layout: "devotional", duration: 24, beats: story },
  { id: "festival-energy", name: "Festival Energy", category: "Festival", description: "Full-bleed cuts, a strong title, and a short count.", layout: "energy", duration: 12, beats: fest },
  { id: "celebration-burst", name: "Celebration Burst", category: "Festival", description: "Tilted picture window and a large word.", layout: "burst", duration: 12, beats: fest },
  { id: "crowd-motion", name: "Crowd Motion", category: "Festival", description: "Tight moving crop for video, with almost no type.", layout: "crowd", duration: 12, beats: fest },
  { id: "heritage-documentary", name: "Heritage Documentary", category: "Documentary", description: "Film edges, a record frame, and a source line.", layout: "doc", duration: 20, beats: doc },
  { id: "historical-story", name: "Historical Story", category: "Documentary", description: "A ruled timeline beside the picture.", layout: "timeline", duration: 20, beats: doc },
  { id: "heritage-frame", name: "Heritage Frame", category: "Heritage", description: "Double frame and an archival caption.", layout: "hframe", duration: 22, beats: doc },
  { id: "culture-journal", name: "Culture Journal", category: "Heritage", description: "Margin notes on paper, picture held to the right.", layout: "journal", duration: 20, beats: doc },
  { id: "minimal-modern", name: "Minimal Modern", category: "Minimal", description: "Wide margin and a single quiet photograph.", layout: "minimal", duration: 16, beats: story },
  { id: "clean-quote", name: "Clean Quote", category: "Minimal", description: "The picture recedes. The line is the scene.", layout: "quote", duration: 16, beats: story },
  { id: "black-white", name: "Black & White", category: "Minimal", description: "Monochrome picture with a vertical side title.", layout: "mono", duration: 18, beats: doc },
  { id: "kinetic-caption", name: "Kinetic Caption", category: "Special", description: "The headline moves. The picture sits underneath.", layout: "kinetic", duration: 12, beats: fest },
  { id: "dynamic-crop", name: "Dynamic Crop", category: "Special", description: "The window itself changes crop from scene to scene.", layout: "dcrop", duration: 14, beats: fest },
  { id: "news-flash", name: "News Flash", category: "Special", description: "Culture desk bar, headline block, and a bottom line.", layout: "news", duration: 12, beats: fest },
  { id: "vertical-label", name: "Vertical Label", category: "Special", description: "Side-set type over a full photograph.", layout: "vlabel", duration: 16, beats: edit },
  { id: "sacred-documentary", name: "Sacred Documentary", category: "Devotional", description: "Arched picture with a documentary caption block.", layout: "sacredoc", duration: 22, beats: doc },
  { id: "festival-cards", name: "Story Cards", category: "Special", description: "One poster card: picture, title, and a quiet footer.", layout: "cards", duration: 16, beats: story },
  { id: "finale", name: "Finale", category: "Special", description: "A closing poster. Picture, then a large name.", layout: "finale", duration: 12, beats: story },
];

const FRAME = ["top rule", "bottom rule", "side rail", "letterbox", "vignette", "outer frame"];

export const TEMPLATES: Template[] = MASTERS.flatMap((master, layoutIndex) =>
  PALETTE_IDS.map((palette, paletteIndex) => {
    const variant = layoutIndex * PALETTE_IDS.length + paletteIndex;
    const motion = MOTIONS[(layoutIndex * 2 + paletteIndex) % MOTIONS.length]!;
    const transition = TRANSITIONS[(layoutIndex + paletteIndex * 3) % TRANSITIONS.length]!;
    const look = PALETTES[palette].name;
    return {
      id: `${master.id}-${palette}`,
      name: `${master.name} · ${look}`,
      category: master.category,
      description: `${master.description} ${look} color, ${motion.replace("-", " ")} motion, ${transition} cut, ${FRAME[variant % FRAME.length]} on a 1080×1920 reel.`,
      layout: master.layout,
      motion,
      transition,
      duration: master.duration + (paletteIndex % 3),
      beats: master.beats,
      palette,
      variant,
    };
  }),
);

export const CATEGORIES: Array<"All" | Category> = [
  "All",
  "Cinematic",
  "Editorial",
  "Magazine",
  "Memory",
  "Collage",
  "Devotional",
  "Festival",
  "Documentary",
  "Heritage",
  "Minimal",
  "Special",
];

export function getTemplate(id: string): Template | undefined {
  return TEMPLATES.find((template) => template.id === id);
}
