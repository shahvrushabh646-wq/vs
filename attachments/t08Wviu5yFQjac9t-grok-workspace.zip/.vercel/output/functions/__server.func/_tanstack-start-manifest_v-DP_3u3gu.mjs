//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DP_3u3gu.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/convert-mp4",
			"/api/media-proxy",
			"/api/media-search",
			"/api/music-search"
		],
		preloads: ["/assets/index-BFZ80Y7c.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BFZ80Y7c.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DIGK8ctY.js"]
	}
} });
//#endregion
export { tsrStartManifest };
